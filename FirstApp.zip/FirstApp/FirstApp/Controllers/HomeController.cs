﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FirstApp.Controllers
{
    public class HomeController:Controller
    {
        public IActionResult Index()
        {
            return View();
            //return View("Index");
            //ViewResult view = new ViewResult();
            //view.ViewName = "Index";
            //return view;
        }

        public string About()
        {
            return "About method";
        }
    }
}
